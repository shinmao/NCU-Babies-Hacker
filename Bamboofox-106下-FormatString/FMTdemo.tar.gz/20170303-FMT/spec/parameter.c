#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 0;

    printf("%3$d, %2$x\n", 16, 17, 18, 19);
    printf("AAAA%2$n", &a, &b);

    printf("a = %d, b = %d\n", a, b);

    return 0;
}
