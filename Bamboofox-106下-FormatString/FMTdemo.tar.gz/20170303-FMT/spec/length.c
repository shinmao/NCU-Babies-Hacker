#include <stdio.h>

int main(void)
{
    int num = 0xabcd1234;

    printf("printf with %%x   : %x\n", num);
    printf("printf with %%hx  : %hx\n", num);
    printf("printf with %%hhx : %hhx\n", num);

    return 0;
}
