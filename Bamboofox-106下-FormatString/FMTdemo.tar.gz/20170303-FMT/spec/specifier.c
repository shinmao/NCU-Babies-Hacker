#include <stdio.h>

int main(void)
{     
    int a = 0;

    printf("%100c%n", 'A', &a);
    printf("\na = %d\n", a);

    return 0;
}
