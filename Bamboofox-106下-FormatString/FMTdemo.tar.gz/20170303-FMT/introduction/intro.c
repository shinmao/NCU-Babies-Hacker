#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
    char buffer[40];

    strncpy(buffer, argv[1], 40);
    printf(buffer);
    printf("\n");

    return 0;
}
