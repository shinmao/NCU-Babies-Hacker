#include <stdio.h>

int main(void)
{
    char buf[16];

    gets(buf);

    return 0;
}
