# -*- coding:utf-8 -*-

str1 = '42414d424f4f464f587b484558746f4153434949697345415353535353597d'
str2 =''
count = 0
temp = ''
for i in str1:
    count+=1
    temp = temp + i
    if count==2:
        str2 = str2 + chr(int(temp,16))
        count=0
        temp=''
print str2
print str1.decode("hex")
