# -*- coding:utf-8 -*-


print 'string'.encode("hex")
print '4261'.decode("hex")
print int('0x4241',16)
print hex(1234)
print bin(1234)
