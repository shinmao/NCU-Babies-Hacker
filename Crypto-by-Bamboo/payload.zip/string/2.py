# -*- coding:utf-8 -*-

str1 = '6977474849644033764480372870271051917784936723179043887694767601277'

print hex(int(str1))
print str(hex(int(str1)))[2:]
print str(hex(int(str1)))[2:].replace("L","")

str2 = str(hex(int(str1)))[2:].replace("L","")
print str2.decode("hex")
